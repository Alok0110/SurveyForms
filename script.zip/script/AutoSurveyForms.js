/*
 * Copyright (c) 2016 - present ALOK DETHE. All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

/*
* version 1.0
*
* 
*/


/* Initiate function call and start execution  */
( function( g ) {
    
    if( !g.jQuery ) { alert( " Api Requires Jquery To Be Loaded First ! " ); return ; }
    
    g.init = { 
        
         /* check for header */
         header : "0",
        
         /* check for image */
         imgCntTotal : 0,
        
         /* keep total question count */
         questCntTotal : 0,
         questVar : "Q",
        
         /* keep total radio count */
         radioCntTotal : 0, 
         radioVar : "r",
        
         /* keep total checkbox count */
         checkBoxCntTotal : 0,
         checkBoxVar : "cxbx",
        
         /* keep total dropdown count */
         dropDownCntTotal : 0,
         dropDownVar : "dd",
        
         /* keep total textarea count */
         textAreaCntTotal : 0,
         textAreaVar : "txtAr",
        
         /* keep total textarea count */
         uploadFileCntTotal : 0,
         uploadFileVar : "upAr",
         
         /* keep track of activities */
         trackObj: { 
             
               quest : "" , 
               opt : "" ,
               upfile : ""
            
         },
        
         /* keep recent Add info */
         recentAdd : ""
        
    };
    
    
    $( "#heading-id" ).draggable( { containment: ".container-box-o", handle: "p", helper : 'clone' } );
   
    $( "#question-id" ).draggable( { containment: ".container-box-o", handle: "p", helper : 'clone' } );
    
    $( "#image-id" ).draggable( { containment: ".container-box-o", handle: "p", helper : 'clone' } );
    
    $( "#radio-id" ).draggable( { containment: ".container-box-o", handle: "p", helper : 'clone' } );
    
    $( "#dropdown-id" ).draggable( { containment: ".container-box-o", handle: "p", helper : 'clone' } );
    
    $( "#txt-area-id" ).draggable( { containment: ".container-box-o", handle: "p", helper : 'clone' } );
    
    $( "#check-box-id" ).draggable( { containment: ".container-box-o", handle: "p", helper : 'clone' } );
    
    $( "#upload-id" ).draggable( { containment: ".container-box-o", handle: "p", helper : 'clone' } );
    
    $( "#sor" ).sortable({
      revert: true
    });
    
    
    
    $( ".holder-col" ).droppable( {
        
      drop: function( event, ui ) {
          
        /*$( this )
          .addClass( "ui-state-highlight" )
          .find( "p" )
            .html( "Dropped!" );*/
          
          console.log( " o " +$( ui.draggable ).first().attr( 'id' ) );
          
          if( $( ui.draggable ).first().attr( 'id' ) === "heading-id" )
              {
                  g.provideFn.addHeading ( this , init , event , ui );
              }
          
          if( $( ui.draggable ).first().attr( 'id' ) === "question-id" )
              {
                  g.provideFn.addQuestions ( this , init , event , ui );
              }
          if( $( ui.draggable ).first().attr( 'id' ) === "image-id" )
              {
                  g.provideFn.addImage( this , init , event , ui );
                  
              }
          if( $( ui.draggable ).first().attr( 'id' ) === "radio-id" )
              {
                  g.provideFn.addRadioOpt( this , init , event , ui );
              }
          if( $( ui.draggable ).first().attr( 'id' ) === "dropdown-id" )
              {
                  g.provideFn.addDropDownOpt( this , init , event , ui );
              }
          if( $( ui.draggable ).first().attr( 'id' ) === "txt-area-id" )
              {
                  g.provideFn.addTextArea( this , init , event , ui );
              }
          if( $( ui.draggable ).first().attr( 'id' ) === "check-box-id" )
              {
                  g.provideFn.addCheckBoxOpt( this , init , event , ui );
                  
              }
          if( $( ui.draggable ).first().attr( 'id' ) === "upload-id" )
              {
                   g.provideFn.addUploadFile( this , init , event , ui );
              }
          
          //console.log("id through event "+$(event).attr('id'));
         
      }
        
    } );
    
    
    g.surveryForm_optionsAccessIds = {
    
            /* Get all image id's */
            getAllImageIds: function(){
                return "got image ids";
            },

            /* Get all question id's */
            getAllQuestionIds: function(){

            },

            /* Get all radio options */
            getAllRadioIds: function(){

            },

            /* Get all dropDown options */
            getAllDropDownIds: function(){

            },

            /* Get all upload document id's */
            getAllUploadDocIds: function(){

            }
    
    }
    
    g.provideFn = { } ; 
    
    g.provideFn.addCheckBoxOpt = function ( comp , init , event , ui )
    {
        if ( g.init.header === "0" ) { alert( "Heading missing!" ); return ; }
        
        if ( g.provideFn.checkTrack( 'CxBx' ) ) {  return ; }
        
        g.init.checkBoxCntTotal = g.init.checkBoxCntTotal + 1;
        
        var li = $("<li></li>");
        
        li.append( $( ui.draggable ).clone() );
        
        $( comp ).find("#sor").append( li );
        //append( $( ui.draggable ).clone() );
        g.provideFn.setTrack( 'CxBx' );  
        //g.init.recentAdd = "CxBx";
        
        var o = $( comp ).find( "#delete-check-id" );
              
          if( o !== null || o !== undefined )
              {
                          //init.header = "1";
                          $( comp ).find( "#delete-check-id" ).css( "display" , "block" );
                          $( comp ).find( "#delete-check-id" ).addClass("invSurvey");
                          /* Register */
                          g.provideFn.reg( '' , '' );
              }
        
    }
    
    g.provideFn.addUploadFile = function ( comp , init , event , ui )
    {
        if ( g.init.header === "0" ) { alert( "Heading missing!" ); return ; }
        
        if ( g.provideFn.checkTrack( 'Up' ) ) {  return ; }
        
        g.init.uploadFileCntTotal = g.init.uploadFileCntTotal + 1;
    
        var li = $("<li></li>");
        
        li.append( $( ui.draggable ).clone() );
        
        $( comp ).find("#sor").append( li );
        
        //$( comp ).append( $( ui.draggable ).clone() );
        g.provideFn.setTrack( 'Up' );  
        //g.init.recentAdd = "Up";
        
        var o = $( comp ).find( "#delete-uploadfile-id" );
              
          if( o !== null || o !== undefined )
              {
                          //init.header = "1";
                          $( comp ).find( "#delete-uploadfile-id" ).css( "display" , "block" );
                          $( comp ).find( "#delete-uploadfile-id" ).addClass("invSurvey");
                          /* Register */
                          g.provideFn.reg( '' , '' );
              }
    }
    
    g.provideFn.addRadioOpt = function ( comp , init , event , ui )
    {
        if ( g.init.header === "0" ) { alert( "Heading missing!" ); return ; }
        
        if ( g.provideFn.checkTrack( 'Rad' ) ) {  return ; }
        
        g.init.radioCntTotal = g.init.radioCntTotal + 1;
    
        var li = $("<li></li>");
        
        li.append( $( ui.draggable ).clone() );
        
        $( comp ).find("#sor").append( li );
        
        //$( comp ).append( $( ui.draggable ).clone() );
        g.provideFn.setTrack( 'Rad' );  
        //g.init.recentAdd = "Rad";
        
        var o = $( comp ).find( "#delete-radio-id" );
              
          if( o !== null || o !== undefined )
              {
                          //init.header = "1";
                          $( comp ).find( "#delete-radio-id" ).css( "display" , "block" );
                          $( comp ).find( "#delete-radio-id" ).addClass("invSurvey");
                          /* Register */
                          g.provideFn.reg( '' , '' );
              }
        
    }
    
    g.provideFn.addDropDownOpt = function ( comp , init , event , ui )
    {
        if ( g.init.header === "0" ) { alert( "Heading missing!" ); return ; }
        
        if ( g.provideFn.checkTrack( 'DD' ) ) { return; }
        
        g.init.dropDownCntTotal = g.init.dropDownCntTotal + 1;
    
         var li = $("<li></li>");
        
         li.append( $( ui.draggable ).clone() );
        
         $( comp ).find("#sor").append( li );
        
        //$( comp ).append( $( ui.draggable ).clone() );
        g.provideFn.setTrack( 'DD' );  
        //g.init.recentAdd = "DD";
        
        var o = $( comp ).find( "#delete-dropdown-id" );
              
          if( o !== null || o !== undefined )
              {
                          //init.header = "1";
                          $( comp ).find( "#delete-dropdown-id" ).css( "display" , "block" );
                          $( comp ).find( "#delete-dropdown-id" ).addClass("invSurvey");
                          /* Register */
                          g.provideFn.reg( '' , '' );
              }
        
    }
    
    g.provideFn.addTextArea = function ( comp , init , event , ui )
    {
        if ( g.init.header === "0" ) { alert( "Heading missing!" ); return ; }
        
        if ( g.provideFn.checkTrack( 'TxtA' ) ) {  return ; }
        
        g.init.textAreaCntTotal = g.init.textAreaCntTotal + 1;
    
         var li = $("<li></li>");
        
         li.append( $( ui.draggable ).clone() );
        
         $( comp ).find("#sor").append( li );
        
        //$( comp ).append( $( ui.draggable ).clone() );
        g.provideFn.setTrack( 'TxtA' );  
        //g.init.recentAdd = "TxtA";
        
        var o = $( comp ).find( "#delete-textarea-id" );
              
          if( o !== null || o !== undefined )
              {
                          //init.header = "1";
                          $( comp ).find( "#delete-textarea-id" ).css( "display" , "block" );
                          $( comp ).find( "#delete-textarea-id" ).addClass("invSurvey");
                          /* Register */
                          g.provideFn.reg( '' , '' );
              }
        
    }
    
    g.provideFn.addImage = function ( comp , init , event , ui )
        {
        
          if ( g.init.header === "0" ) { alert( "Heading missing!" ); return ; }
        
          if( g.provideFn.checkTrack( 'I' ) ) { return ; }
        
          g.init.imgCntTotal = g.init.imgCntTotal + 1;
        
          var arrop = $( ui.draggable ).clone();
        
          g.provideFn.setTrack( 'I' );  
        
          //g.init.recentAdd = "I";
          
          //g.init.questCntTotal = g.init.questCntTotal + 1;
           
        
          /* assign unique id */
          $( arrop ).get(0).getElementsByTagName( 'img' ).item(0).setAttribute( 'id' , 'img' + g.init.imgCntTotal );
    
          console.log( ' img ' + $( arrop ).get(0).getElementsByTagName( 'img' ).item(0).getAttribute( 'id' ) );
        
          var li = $("<li></li>");
        
          li.append( arrop );
        
          $( comp ).find("#sor").append( li );
        
          //$( comp ).append( arrop );
    
          var o = $( comp ).find( "#delete-image-id" );
              
          if( o !== null || o !== undefined )
              {
                          //init.header = "1";
                  
                          $( comp ).find( "#delete-image-id" ).css( "display" , "block" );
                          $( comp ).find( "#delete-image-id" ).addClass( 'img' + g.init.imgCntTotal );
                          /* Register */
                          g.provideFn.reg( 'img' + g.init.imgCntTotal , 'I' );
                  
                          
              }
        }
    
    /* Track Activities */
    g.provideFn.setTrack = function ( o )
    {
        if( o === 'Q' ) g.init.trackObj.quest = o;
        
        if( o !== 'Q' ){
            
            if( o === 'Up' )
            {
                    g.init.trackObj.upfile = o;
            }
            else if ( o === 'I' ) /* video edit */
            {
                    g.init.trackObj.quest = o;
            }
            else
            {
                    g.init.trackObj.opt = o;
            }
            
        } 
    }
    
    /* Common Track Check Function */
    g.provideFn.commonTrackCheck_1 = function ( o )
    {
        
         if( g.init.trackObj.quest === 'Q' )
                  {  
                        if ( g.init.trackObj.opt === o )
                            {
                                return false;
                            }
                        else if ( g.init.trackObj.opt !== '' ) {
                               alert( "Only One Type Of Option's Are Allowed !" );
                               return true;
                            }
                        else  if ( g.init.trackObj.opt === '' ){
                               return false;
                        }
                
                  }
                  else{
                      alert( "Add A Question First !" );
                      return true;
                  }
        
    }
    
    /* Common Track Check Function */
    g.provideFn.commonTrackCheck_2 = function ( o )
    {
        if( g.init.trackObj.quest === 'Q' )
                  {  
                        if( g.init.trackObj.opt ===  o )
                            {
                                alert( "Text Area Already Added !" );
                                return true;
                            }
                        else if ( g.init.trackObj.opt !== '' ) {
                               alert( "Only One Type Of Option's Are Allowed !" );
                               return true;
                            }
                        else  if ( g.init.trackObj.opt === '' ){
                               return false;
                        }
                
                  }
                  else{
                      alert( "Add A Question First !" );
                      return true;
                  }
    }
    
    /* Check Activities */
    g.provideFn.checkTrack = function ( o )
    {
        if( o === 'Q' )
            {
                if( g.init.trackObj.quest === 'Q' )
                  {  
                        if( g.init.trackObj.opt === '' )
                            {
                                alert( "Set Options For Previous Question Before Adding Next Question !" );
                                return true;
                            }
                        else {
                               alert( "Please Save Question Before Adding Next Question !" );
                               return true;
                        }
                
                  }
                else if( g.init.trackObj.quest === '' )
                    {
                        //alert( "Question Save !" );
                        console.log ( " Always show this opt " + g.init.trackObj.opt + " quest " + g.init.trackObj.quest + " upfile " + g.init.trackObj.upfile   );
                        return false;
                    }
                else if ( g.init.trackObj.quest === 'I' ) /* Video Edit */
                    {
                        g.provideFn.resetTrack ( );
                         console.log ( " Always show this opt " + g.init.trackObj.opt + " quest " + g.init.trackObj.quest + " upfile " + g.init.trackObj.upfile   );
                        return false;
                    }
                
            }
        
        if( o === 'I' )
            {
                if( g.init.trackObj.quest === '' )
                  {  
                        return false;
                  }
                else if( g.init.trackObj.quest === 'I' )
                    {
                        alert( "Image Already Added !" );
                        return true;
                    }
                else {
                        alert( "Image Should Be Added Before Selecting Question Or After Saving Old Question !" );
                        return true;
                }
            }
        
        if( o === 'TxtA' || o === 'DD' ) 
            {
                return g.provideFn.commonTrackCheck_2 ( o );
            }
        
        if ( o === 'CxBx' || o === 'Rad' )
            {
                return g.provideFn.commonTrackCheck_1 ( o );
            }
        
        
        if( o === 'Up' )
            {
                
                if( g.init.trackObj.quest === 'Q' )
                  {  
                        if( g.init.trackObj.upfile ===  'Up' )
                            {
                                alert( "File Upload Already Added !" );
                                return true;
                            }
                        else  if ( g.init.trackObj.upfile === '' ){
                               return false;
                        }
                
                  }
                  else{
                      alert( "Add A Question First !" );
                      return true;
                  }
                
            }
        
    }
    
    /* Reset Activities */
    g.provideFn.resetTrack = function ( )
    {
        
        g.init.trackObj.quest = "";
        
        g.init.trackObj.opt = "";
        
        g.init.trackObj.upfile = "";
    }
    
    g.provideFn.addQuestions = function ( comp , init , event , ui )
    {
          if ( g.init.header === "0" ) { alert( "Heading missing!" ); return ; }
    
           if( g.provideFn.checkTrack( 'Q' ) ) { return ; }
        
           var li = $("<li></li>");
        
           li.append( $( ui.draggable ).clone() );
        
           $( comp ).find("#sor").append( li );
          //$( comp ).append( $( ui.draggable ).clone() );
        
           g.init.questCntTotal = g.init.questCntTotal + 1;
           
           ( $( li ).children().get(0).childNodes ).item( 1 ).setAttribute( 'id' , 'Q' + g.init.questCntTotal );
    
           g.provideFn.setTrack( 'Q' );
        
          //g.init.recentAdd = "Q";
        
          var o = $( comp ).find( "#delete-survey-id" );
              
    
          if( o !== null || o !== undefined )
              {
                          //init.header = "1";
                          $( comp ).find( "#delete-survey-id" ).css( "display" , "block" );
                          $( comp ).find( "#delete-survey-id" ).addClass( 'Q' + g.init.questCntTotal );
                          /* Register */
                          g.provideFn.reg( 'Q' + g.init.questCntTotal , 'Q' );
              }
    }

    g.provideFn.addHeading = function ( comp , init , event , ui )
    {
        /* Don't repeat heading */
        if( g.init.header === "0" ) { 
            
            var li = $("<li></li>");
        
            li.append( $( ui.draggable ).clone() );
        
            $( comp ).find("#sor").append(li);
            
            $('.holder-col').css( 'height' , 'auto' );
                //.append(li);
            //$( comp ).append( $( ui.draggable ).clone() ); 
        
        } else { alert("One Heading Per Form !") }
        
        g.init.recentAdd = "H";
        
          /* Get an element after adding it, and set the css to display  */
          var o = $( comp ).find( "#delete-heading-id" );
          
          if( o !== null || o !== undefined )
              {
                  if( g.init.header === "0" )
                      {
                          g.init.header = "1";
                          $( comp ).find( "#delete-heading-id" ).css( "display" , "block" );
                          $( comp ).find( "#delete-heading-id" ).addClass("invHead");
                          /* Register */
                          g.provideFn.reg( 'invHead' , '' );
                      }
                  else{
                      
                  }
              }
    }
    
    g.com_surveyForms_predefined_del = function ( o , typeOf ) {
        
                    ($( o ).parent()).parent().remove();
        
                    if( typeOf === 'Q' )
                        {
                            g.provideFn.resetTrack();
                            console.log(' remove all options ! ');
                        }
                    
                    if( typeOf === 'I' ) /* video Related */
                        {
                            g.provideFn.resetTrack();
                            console.log( ' remove all image related detail ' );
                        }
        
    }
    
    /* Register */
    g.provideFn.reg = function ( str , typeOf )
    {
        
        if( str === 'invHead' )
            {
                $(".invHead").click(function(){
                    
                    alert(" Cannot Delete Heading !");
            
                });
            }
        
    }
    
    $('#cTemp').click(function(){
        alert('Creating Template Please Wait !');
    });
    
    $('#cForm').click(function(){
        alert(' Version 1.0 ');
    });
    
    $('#cQuest').click(function(){
        //alert("In Save Form!");
        
          if( g.init.trackObj.quest === 'Q' )
              {
                  if( g.init.trackObj.opt === '' )
                      {
                          alert( "Please Add Option's To Question Before Saving!" );
                      }
                  else {
                      g.provideFn.resetTrack();
                  }
              }
        else {
            alert("Question Not Found Or Question Already Saved !");
        }
          
    });
    
  }( this ) );


